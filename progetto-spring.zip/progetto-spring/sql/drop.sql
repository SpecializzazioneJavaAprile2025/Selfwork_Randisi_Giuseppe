DROP TABLE comments;
DROP TABLE posts;
DROP TABLE authors;
 