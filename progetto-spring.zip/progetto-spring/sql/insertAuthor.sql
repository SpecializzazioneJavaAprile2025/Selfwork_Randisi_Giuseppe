INSERT INTO authors (firstname, lastname, email)
value ("Franco", "Scoglio", "ScogliFranco@prova.it");

INSERT INTO authors (firstname, lastname, email)
value ("Marco", "Giovanardi", "Giovanardi@prova.it");

