INSERT INTO comments(email, body, date, post_id)
value ("ScogliFranco@prova.it", "Franco SCOGLIO GIOCAA LA BRISCOLAAAA", "20250530",1);

INSERT INTO comments(email, body, date, post_id)
value ("Giovanardi@prova.it", "GIOVANARDI CHE FUMA GANJA", "20250530" ,2);

